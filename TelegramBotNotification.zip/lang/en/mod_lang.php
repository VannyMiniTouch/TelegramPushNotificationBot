<?php
	$lang = array(
		"HOME"=>"HOME",
		"PRODUCT"=>"PRODUCT",
		"CONTACT US"=>"CONTACT US",
		"ABOUT US"=>"ABOUT US",
		"About Company"=>"About Company",
		"Our Product"=>"Our Product",
		"Our Project"=>"Our Project",
	);


?>