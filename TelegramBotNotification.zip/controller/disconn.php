<?php
$con -> close();
?>